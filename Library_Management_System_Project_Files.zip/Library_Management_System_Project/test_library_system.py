import unittest
from library_system import (
    Book, Person, Member, StudentMember, FacultyMember, Librarian,
    Loan, Catalog, Library, GuestMember
)


class TestLibraryManagementSystem(unittest.TestCase):
    def setUp(self):
        self.library = Library("VIT Central Library")
        self.book = Book("B001", "Python Basics", "A. Author")
        self.student = StudentMember("M001", "Hari", "hari@example.com", "23MIY0114")
        self.faculty = FacultyMember("M002", "Dr. Rao", "rao@example.com", "CSE")
        self.librarian = Librarian("L001", "Meena", "meena@example.com", "EMP01")
        self.library.add_book(self.book)
        self.library.add_librarian(self.librarian)

    def test_every_concrete_class_and_method(self):
        self.assertEqual(self.book.get_details().split(":")[0], "B001")
        self.book.mark_borrowed()
        self.assertFalse(self.book.is_available)
        self.book.mark_returned()
        self.assertTrue(self.book.is_available)

        self.assertEqual(self.student.get_role(), "Member")
        self.assertEqual(self.student.get_membership_type(), "Student")
        self.assertEqual(self.faculty.get_role(), "Member")
        self.assertEqual(self.faculty.get_membership_type(), "Faculty")
        self.assertEqual(self.librarian.get_role(), "Librarian")
        self.assertIn("registered", self.librarian.register_member(self.student))

        catalog = Catalog()
        catalog.add_book(self.book)
        self.assertIs(catalog.find_book("B001"), self.book)
        self.assertEqual(len(catalog.list_books()), 1)

        loan = Loan("LN001", self.student, self.book)
        self.library.issue_book(loan)
        self.assertIn("Student", loan.get_summary())
        self.assertEqual(len(self.student.active_loans), 1)
        self.library.return_book(loan)
        self.assertTrue(loan.is_returned)
        self.assertEqual(len(self.student.active_loans), 0)

        self.assertIs(self.library.search_book("B001"), self.book)
        self.assertEqual(len(self.library.loans), 0)

        guest = GuestMember("G001", "Arun", "arun@example.com", "PASS01")
        self.assertEqual(guest.get_role(), "Member")
        self.assertEqual(guest.get_membership_type(), "Guest")
        guest_loan = Loan("LN002", guest, self.book)
        self.assertIn("Guest", guest_loan.get_summary())

    def test_abstract_classes_cannot_be_instantiated(self):
        with self.assertRaises(TypeError):
            Person("P", "Name", "a@b.com")
        with self.assertRaises(TypeError):
            Member("M", "Name", "a@b.com")

    def test_duplicate_book_is_rejected(self):
        with self.assertRaises(ValueError):
            self.library.add_book(Book("B001", "Another", "Writer"))


if __name__ == "__main__":
    unittest.main(verbosity=2)
