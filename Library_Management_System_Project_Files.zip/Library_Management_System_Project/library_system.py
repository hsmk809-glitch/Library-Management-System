from abc import ABC, abstractmethod


class Book:
    """A book held in the library catalogue."""

    def __init__(self, book_id, title, author):
        self.book_id = book_id
        self.title = title
        self.author = author
        self.is_available = True

    def mark_borrowed(self):
        if not self.is_available:
            raise ValueError("Book is already borrowed.")
        self.is_available = False

    def mark_returned(self):
        self.is_available = True

    def get_details(self):
        status = "Available" if self.is_available else "Borrowed"
        return f"{self.book_id}: {self.title} by {self.author} ({status})"


class Person(ABC):
    """Abstract base class for people who use or manage the library."""

    def __init__(self, person_id, name, email):
        self.person_id = person_id
        self.name = name
        self.email = email

    @abstractmethod
    def get_role(self):
        pass


class Member(Person, ABC):
    """Abstract library member. Concrete member types define their category."""

    def __init__(self, person_id, name, email):
        super().__init__(person_id, name, email)
        self.active_loans = []

    @abstractmethod
    def get_membership_type(self):
        pass

    def add_loan(self, loan):
        self.active_loans.append(loan)

    def remove_loan(self, loan):
        if loan in self.active_loans:
            self.active_loans.remove(loan)


class StudentMember(Member):
    def __init__(self, person_id, name, email, student_id):
        super().__init__(person_id, name, email)
        self.student_id = student_id

    def get_role(self):
        return "Member"

    def get_membership_type(self):
        return "Student"


class FacultyMember(Member):
    def __init__(self, person_id, name, email, department):
        super().__init__(person_id, name, email)
        self.department = department

    def get_role(self):
        return "Member"

    def get_membership_type(self):
        return "Faculty"


class Librarian(Person):
    def __init__(self, person_id, name, email, employee_id):
        super().__init__(person_id, name, email)
        self.employee_id = employee_id

    def get_role(self):
        return "Librarian"

    def register_member(self, member):
        if not isinstance(member, Member):
            raise TypeError("Only Member objects can be registered.")
        return f"{member.name} registered by {self.name}"


class Loan:
    """Records the borrowing of one book by one member."""

    def __init__(self, loan_id, member, book):
        if not isinstance(member, Member):
            raise TypeError("loan member must be a Member.")
        if not isinstance(book, Book):
            raise TypeError("loan book must be a Book.")
        self.loan_id = loan_id
        self.member = member
        self.book = book
        self.is_returned = False

    def issue(self):
        if self.is_returned:
            raise ValueError("A returned loan cannot be issued again.")
        self.book.mark_borrowed()
        self.member.add_loan(self)

    def return_book(self):
        if self.is_returned:
            raise ValueError("Book has already been returned.")
        self.book.mark_returned()
        self.member.remove_loan(self)
        self.is_returned = True

    def get_summary(self):
        # Uses the Member abstraction, not a subclass-only field.
        return (f"Loan {self.loan_id}: {self.book.title} -> "
                f"{self.member.name} ({self.member.get_membership_type()})")


class Catalog:
    """Owns the collection of Book objects for this library."""

    def __init__(self):
        self.books = []

    def add_book(self, book):
        if not isinstance(book, Book):
            raise TypeError("Only Book objects can be added.")
        if any(existing.book_id == book.book_id for existing in self.books):
            raise ValueError("A book with this ID already exists.")
        self.books.append(book)

    def find_book(self, book_id):
        for book in self.books:
            if book.book_id == book_id:
                return book
        return None

    def list_books(self):
        return [book.get_details() for book in self.books]


class Library:
    """Main system; composition: a Library owns its Catalog."""

    def __init__(self, name):
        self.name = name
        self.catalog = Catalog()
        self.librarians = []
        self.loans = []

    def add_librarian(self, librarian):
        if not isinstance(librarian, Librarian):
            raise TypeError("Only Librarian objects can be added.")
        self.librarians.append(librarian)

    def add_book(self, book):
        self.catalog.add_book(book)

    def issue_book(self, loan):
        if self.catalog.find_book(loan.book.book_id) is None:
            raise ValueError("Book is not in this library catalogue.")
        if loan.book.is_available is False:
            raise ValueError("Book is not available.")
        loan.issue()
        self.loans.append(loan)

    def return_book(self, loan):
        if loan not in self.loans:
            raise ValueError("Loan does not belong to this library.")
        loan.return_book()
        self.loans.remove(loan)

    def search_book(self, book_id):
        return self.catalog.find_book(book_id)


class GuestMember(Member):
    """Extension added after the original design; existing classes stay unchanged."""

    def __init__(self, person_id, name, email, visit_pass):
        super().__init__(person_id, name, email)
        self.visit_pass = visit_pass

    def get_role(self):
        return "Member"

    def get_membership_type(self):
        return "Guest"
